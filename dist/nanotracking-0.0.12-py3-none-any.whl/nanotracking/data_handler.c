#define PY_SSIZE_T_CLEAN
#include <Python.h>
// #include <sys/types.h>
// #include <sys/stat.h>

static PyObject *parse_data(PyObject *self, PyObject *args, PyObject *kwargs) {
    static char *keywords[] = {"dat_path", "num_data_points"}; // num_data_points is optional (denoted by |)
    const char *dat_path;
    int num_data_points;
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s|i", keywords, &dat_path, &num_data_points))
        return NULL;
    
    FILE *filePtr;
    filePtr = fopen(dat_path, "r");
    fclose(filePtr);

    Py_INCREF(Py_None);
    return Py_None;
}

static PyMethodDef SpamMethods[] = {
    {"parse_data",  parse_data, METH_VARARGS, ""},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

static struct PyModuleDef spammodule = {
    PyModuleDef_HEAD_INIT,
    "spam",   /* name of module */
    NULL, /* module documentation, may be NULL */
    -1,       /* size of per-interpreter state of the module, or -1 if the module keeps state in global variables. */
    SpamMethods
};

PyMODINIT_FUNC PyInit_spam(void) {
    return PyModule_Create(&spammodule);
}

// int main(int argc, char *argv[]) {
//     wchar_t *program = Py_DecodeLocale(argv[0], NULL);
//     if (program == NULL) {
//         fprintf(stderr, "Fatal error: cannot decode argv[0]\n");
//         exit(1);
//     }

//     /* Add a built-in module, before Py_Initialize */
//     if (PyImport_AppendInittab("spam", PyInit_spam) == -1) {
//         fprintf(stderr, "Error: could not extend in-built modules table\n");
//         exit(1);
//     }

//     /* Pass argv[0] to the Python interpreter */
//     Py_SetProgramName(program);

//     /* Initialize the Python interpreter.  Required.
//        If this step fails, it will be a fatal error. */
//     Py_Initialize();

//     /* Optionally import the module; alternatively,
//        import can be deferred until the embedded script
//        imports it. */
//     PyObject *pmodule = PyImport_ImportModule("spam");
//     if (!pmodule) {
//         PyErr_Print();
//         fprintf(stderr, "Error: could not import module 'spam'\n");
//     }

//     ...

//     PyMem_RawFree(program);
//     return 0;
// }